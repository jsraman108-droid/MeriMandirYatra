# Meri Mandir Yatra — Android project

This is an Android Studio wrapper for the existing single-file Meri Mandir Yatra app. It loads the app from `app/src/main/assets/index.html` in a WebView. JavaScript and DOM storage are enabled so the temple tracker can retain its local data on the device. External web links (ChatGPT, IMD, NTES, Google Maps, registration portals) open outside the app in the appropriate browser/app.

## Build APK
1. Install Android Studio on a computer.
2. Open this project folder (`MeriMandirYatraAndroid`) in Android Studio.
3. Allow Gradle sync and install Android SDK Platform 35 if prompted.
4. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Android Studio will create the debug APK at `app/build/outputs/apk/debug/app-debug.apk`.
6. Transfer the APK to your Android phone and install it. If Android asks, allow installing unknown apps for the app used to open the APK.

## Important
- This project is an Android Studio source project, not a compiled APK.
- The AI feature hands a prepared prompt to ChatGPT; it is not an embedded AI API connection.
- Weather, roads, temple, registration and train links open external official sources/search pages. They are not background push updates.
- Tracker data is stored locally on the phone's WebView storage. Clearing app data can erase it; use the app's export/backup feature if one is available in the HTML version.
